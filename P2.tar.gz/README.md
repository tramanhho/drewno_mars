# drewno_mars

Drew, 

We have now implemented a Makefile. You will be able to run this project just like any other this semester, but you will still need Rust and `cargo` installed. If necessary, you can use the following terminal command.

```shell
$ curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
```